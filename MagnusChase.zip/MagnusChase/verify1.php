<html>
<body>

<?php
$str = $_POST["flag_unvalidated"];

if (sha1($str) == "b1420bf24fd8e2b0416c9884f3ff0afe920071a9")
{
    header('Location: level2.html');
    exit;
}
else
{
    header('Location: level1.html');
    exit;
}
?>

</body>
</html>