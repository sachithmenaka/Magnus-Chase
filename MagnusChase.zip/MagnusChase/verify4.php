<html>
<body>

<?php
$str = $_POST["inputPassword2"];

if (sha1($str) == "b1420bf24fd8e2b0416c9884f3ff0afe920071a9")
{
    header('Location: level5.html');
    exit;
}
else
{
    header('Location: level4.html');
    exit;
}
?>

</body>
</html>